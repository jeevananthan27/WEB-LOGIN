# Progressive sign up 

A Pen created on CodePen.io. Original URL: [https://codepen.io/jdniki/pen/rewxPo](https://codepen.io/jdniki/pen/rewxPo).

